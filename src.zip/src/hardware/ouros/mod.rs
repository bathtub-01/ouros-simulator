pub mod program;

pub mod combinator;

pub mod reducer;

pub mod deref_heap_new;

pub mod alu;

pub mod config;

pub mod benchmarks;

pub mod ouros_core;

pub mod garbage_collector;

pub mod addr_box;

pub mod io_unit;
