// ALU, simply takes an application and produce the result.
// It allows over-applied applications, e.g., ((=) 1 2 a b) = (FALSE a b)
//           +------------+
//  input ==>|     ALU    |===> output
//           +------------+

use super::program::AluOp::*;
use super::program::Atom::*;
use crate::{
    hardware::{
        ouros::{
            config::*,
            program::{AluOp, App},
        },
        utils::fire,
    },
    hw_module::{HwInput, HwModule},
};

use super::program::*;

#[derive(Default)]
pub struct AluInput {
    pub input_valid: bool,
    pub input_bits: ActiveApp,
    pub output_ready: bool,
}

impl HwInput for AluInput {}

pub fn compute(op: &AluOp, rev: bool, l: i32, r: i32) -> Atom {
    fn comb_bool(b: bool, inv: bool) -> Atom {
        if b ^ inv {
            // COM(2, 0, [1, 0, 0, 0, 0, 0]) // MicroHs - True
            Com(2, 1) // True, always be placed at 0
        // CON(1, 0, 1)
        } else {
            // COM(2, 0, [0, 0, 0, 0, 0, 0]) // MicroHs - False
            Com(2, 0) // False
            // CON(1, 0, 0)
        }
    }

    match op {
        EQ => comb_bool(l == r, rev),
        LE => comb_bool(l <= r, rev),
        LT => comb_bool(l < r, rev),
        Add => Int(l + r),
        Sub => Int(l - r),
        Mul => Int(l * r),
    }
}

#[derive(Default)]
pub struct AluStat {
    pub busy_cycles: u32,
    pub busy_per_cycle: Vec<bool>,
    pub reductions: u32,
    pub holder_contents: Vec<Option<ActiveApp>>,
}

#[derive(Default)]
pub struct Alu {
    pub input: AluInput,
    holder: (bool, ActiveApp),
    stat: AluStat,
    stat_detail_lv: u8,
}

impl Alu {
    pub fn new() -> Self {
        Alu {
            input: AluInput {
                input_valid: false,
                input_bits: Default::default(),
                output_ready: true,
            },
            holder: Default::default(),
            stat: Default::default(),
            stat_detail_lv: Default::default(),
        }
    }

    pub fn detail(mut self, lv: u8) -> Self {
        self.stat_detail_lv = lv;
        self
    }

    fn input_fire(&self) -> bool {
        self.input.input_valid && self.input_ready()
    }

    fn output_fire(&self) -> bool {
        self.output_valid() && self.input.output_ready
    }

    pub fn input_ready(&self) -> bool {
        if ALU_PIPE {
            !self.holder.0 || self.output_fire()
        } else {
            self.output_fire()
        }
    }

    pub fn output_valid(&self) -> bool {
        if ALU_PIPE {
            self.holder.0
        } else {
            self.input.input_valid
        }
    }

    pub fn output_bits(&self) -> Result<ActiveApp, String> {
        if ALU_PIPE {
            Ok(self.holder.1.clone())
        } else {
            self.gen_result()
        }
    }

    pub fn get_stat(&self) -> &AluStat {
        &self.stat
    }

    fn gen_result(&self) -> Result<ActiveApp, String> {
        let get_operand = |i: usize| -> Result<i32, String> {
            self.input
                .input_bits
                .load
                .get(i)
                .ok_or(format!("{} operand could not be load", i))
                .and_then(take_int)
        };

        let oprand1: i32 = get_operand(1)?;
        let oprand2: i32 = get_operand(2)?;

        self.input
            .input_bits
            .load
            .first()
            .ok_or("failed to load input bits".to_string())
            .and_then(|atom| match atom {
                Prm(op, inv) => Ok(ActiveApp {
                    stack_idx: self.input.input_bits.stack_idx,
                    load: {
                        let res = compute(op, *inv, oprand1, oprand2);
                        let mut arr: App = Default::default();
                        arr[0] = res;
                        for i in 3..APP_LENGTH {
                            if self.input.input_bits.load[i] != Nop {
                                arr[i - 2] = self.input.input_bits.load[i];
                            } else {
                                break;
                            }
                        }
                        arr
                    },
                }),
                _ => Err("alu: app head is not an primitive op!".to_string()),
            })
    }
}

impl HwModule for Alu {
    fn update_local(&mut self) -> Result<(), String> {
        if fire(self.holder.0, self.input.output_ready) {
            self.holder.0 = false;
        }

        if self.input_fire() {
            self.holder.0 = true;
            self.holder.1 = self.gen_result()?;
        }
        Ok(())
    }

    fn update_stat(&mut self) -> std::result::Result<(), std::string::String> {
        if self.input_fire() {
            self.stat.reductions += 1;
        }

        if self.stat_detail_lv >= DLV_BUSY_RATE {
            if fire(self.input.input_valid, self.input_ready()) {
                self.stat.busy_cycles += 1;
                self.stat.busy_per_cycle.push(true);
            } else {
                self.stat.busy_per_cycle.push(false);
            }
        }

        if self.stat_detail_lv >= DLV_FULL_LOG {
            if self.holder.0 {
                self.stat.holder_contents.push(Some(self.holder.1.clone()));
            } else {
                self.stat.holder_contents.push(None);
            }
        }
        Ok(())
    }

    fn tick_children(&mut self) -> std::result::Result<(), std::string::String> {
        Ok(())
    }
}

#[test]
fn alu_spec() {
    use Atom::*;
    let mut alu = Alu::new();

    alu.tick();
    alu.input.link(|input| {
        input.output_ready = false;
        input.input_valid = true;
        input.input_bits.stack_idx = 2;
        input.input_bits.load = [
            Prm(AluOp::LE, false),
            Int(7),
            Int(7),
            Ptr(11, false, false),
            Ptr(22, false, false),
            Nop,
            Nop,
            Nop,
        ];
    });
    alu.tick();
    println!("{:?}, valid: {}", alu.output_bits(), alu.output_valid());

    alu.input.link(|input| {
        input.output_ready = true;
        input.input_valid = false;
    });
    alu.tick();
    println!("{:?}, valid: {}", alu.output_bits(), alu.output_valid());
}
