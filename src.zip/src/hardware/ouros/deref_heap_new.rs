// Dereference Heap, also handles thread management:
//           +-----------------+
// addr  <-->|    Dereference  |===> out_main
// port_a ==>|                 |
// port_b ==>|       Heap      |===> out_sub
//           +-----------------+

use super::config::*;
use super::program::*;
use crate::hardware::common::memory::DualPortMemStat;
use crate::hardware::common::{DualPortMem, Register, Stack};
use crate::hardware::utils::fire;
use crate::hw_module::{HwInput, HwModule};
use std::cmp::max;
use std::fmt;

#[derive(Default)]
pub struct DrfHeapInput {
    pub start: bool,
    pub port_a_valid: bool,
    pub port_a_bits: ActiveApp,
    pub port_b_valid: bool,
    pub port_b_bits: FrozenApp,
    pub out_main_ready: bool,
    /// IO request channel (response re-enters port_a through core arbitration).
    pub out_io_ready: bool,
    pub out_sub_ready: bool,
    pub found: bool,
    // GC signals
    pub free_addr: usize,
    pub free_addr_valid: bool,
    pub read_heap_req_valid: bool,
    pub read_heap_req_addr: usize,
}

impl HwInput for DrfHeapInput {}

type StackCell = (bool, usize);
type AddrStack = Stack<StackCell, ADDR_STK_SIZE>;
type FrameRecord = [usize; MAX_THREADS];
type FrameStack = Stack<FrameRecord, FRM_STK_SIZE>;

fn stack_cell_with(cell: Option<&StackCell>, p: impl FnOnce(&StackCell) -> bool) -> bool {
    match cell {
        Some(c) => p(c),
        None => false,
    }
}

fn find_more_dmder(address: usize) -> impl Fn(&AddrStack) -> bool {
    move |s| {
        stack_cell_with(s.top(), |(_, addr)| *addr == address)
            && stack_cell_with(s.second(), |(flag, _)| !*flag)
    }
}

fn find_new_frame(address: usize) -> impl Fn(&AddrStack) -> bool {
    move |s| {
        stack_cell_with(s.top(), |(_, addr)| *addr == address)
            && stack_cell_with(s.second(), |(flag, _)| *flag)
    }
}

fn find_free_stack(s: &AddrStack, target_addr: usize) -> bool {
    s.elements() == 0 || stack_cell_with(s.top(), |(flag, addr)| *flag && *addr == target_addr)
}

fn extend_to_app<const N: usize>(atms: &[Atom; N]) -> App {
    let mut extended: App = std::array::from_fn(|_| Atom::Nop);
    for (i, a) in atms.iter().enumerate() {
        extended[i] = *a;
    }
    extended
}

/// cancel all the unique PTRs in an app
fn dash_app(app: &App) -> App {
    let mut res = *app;
    for atom in res.iter_mut() {
        if let Atom::Ptr(p, _, false) = atom {
            *atom = Atom::Ptr(*p, false, false);
        }
    }
    res
}

/// setup the evaluated flag in seq if the 1st arg is a literal
fn mask_seq(app: &App) -> App {
    // match app[0] {
    //     Atom::Seq(false) => {
    //         if is_lit_atom(&app[1]) {
    //             let mut res: App = app.clone();
    //             res[0] = Atom::Seq(true);
    //             res
    //         } else {
    //             app.clone()
    //         }
    //     }
    //     _ => app.clone(),
    // }
    *app
}

enum HeapPort {
    A,
    B,
}

#[derive(Default, Clone, PartialEq, Debug)]
// FIX: should we fix capitalisation of variant names?
pub enum Stm {
    #[default]
    Idle,
    Whnf,
    Ia,
    Resume,
}

#[derive(Default)]
pub struct DrfHeapStat {
    active_threads: u8,
    pub work_threads: Vec<(u8, u8)>, // (occupied resources, active threads)
    pub busy_per_cycle: Vec<bool>,
    pub holder_contents: Vec<Option<ActiveApp>>,
    pub heap_stm: Vec<Stm>,
    pub serving_id: Vec<u8>,
    pub stm_cycles: [u32; 4],
    pub heap_update: u32,
    pub update_avoided: u32,
    pub gc_stall_cycles: u32,  // gc stall in total
    pub gc_current_stall: u32, // current contiguous stall
    pub gc_longest_stall: u32, // longest contiguous stall
}

/// branch conditions for `consume_next()`
#[derive(Debug, PartialEq)]
enum CONSUMEs {
    NoInput,
    /// input is an IA
    InputIA,
    /// saturated IO with unboxed strict operands; issue only once.
    InputIOReady,
    /// completed IO Pair with a case-table/extra application must reduce.
    InputForwardReducer,
    /// input is an WHNF; demander found in any stacks
    InputWHNFWithDmder,
    /// input is an WHNF; no demander is found; different frame under the WHNF
    InputWHNFNoDmderNewFrame,
    /// input is an WHNF; no demander is found; the WHNF the only element on the stack
    InputWHNFNoDmderNoFrame,
}

/// branch conditions for the `WHNF` state
#[derive(Debug, PartialEq)]
enum WHNFs {
    MoreDmders,
    NewFrame,
    NoNewFrame,
}

/// branch conditions for the `IA` state, part 1
#[derive(PartialEq, Debug)]
enum IAs1 {
    NoExist,
    ExistWHNF,
    ExistIAWorkingNormal,
    ExistIAWorkingAtNewFrame,
    ExistIAFresh,
}

/// branch conditions for the `IA` state, part 2
#[derive(Debug)]
enum IAs2 {
    NextStrictArgLocal,
    NextStrictArgNewStk,
    NoMoreArgsCanEmit,
    NoMoreArgsNoEmit,
}

/// branch conditions for the `RESUME` state
enum RESUMEs {
    TopInWHNF,
    TopInIA,
}

/// select the first pointer to deref, returns (arg position, pointer value)
fn select_1st_arg(app: &App) -> Result<(usize, usize), String> {
    match app[0] {
        Atom::Ptr(p, _, false) => Ok((0, p)),
        Atom::Prm(_, _) => match app[1] {
            Atom::Ptr(p, _, false) => Ok((1, p)),
            _ => match app[2] {
                Atom::Ptr(p, _, false) => Ok((2, p)),
                _ => Err(format!("PRM has no strict pointer: {:?}", app)),
            },
        },
        Atom::IO(_) => {
            for &idx in io_strict_positions(&app[0]) {
                if !is_int(&app[idx]) && !matches!(app[idx], Atom::Ptr(_, _, false)) {
                    return Err(format!("IO argument {} must be INT or PTR: {:?}", idx, app));
                }
            }
            io_next_pointer(app, 0).ok_or_else(|| {
                format!("saturated IO requires INT or PTR strict operands: {:?}", app)
            })
        }
        Atom::Try | Atom::Seq => match app[1] {
            Atom::Ptr(p, _, false) => Ok((1, p)),
            _ => Err(format!("No Ptr here: {:?}", app)),
        },
        _ => Err(format!("app: {:?}", app)),
    }
}

/// A strict IO pointer must resolve to an unboxed INT, not a constructor
/// or partial application that merely happens to be in WHNF.
fn check_io_target(app: &App, arg_id: usize, target: &App) -> Result<(), String> {
    if is_io(&app[0]) && arg_id != 0 && (app_length(target) != 1 || !is_int(&target[0])) {
        return Err(format!(
            "IO strict argument {} expected unboxed INT, got {:?}", arg_id, target
        ));
    }
    Ok(())
}

fn select_next_arg(app: &App, current: usize) -> Result<(usize, usize), String> {
    if is_io(&app[0]) {
        return io_next_pointer(app, current)
            .ok_or_else(|| format!("IO has no further strict pointer: {:?}", app));
    }
    match app[2] {
        Atom::Ptr(p, _, false) => Ok((2, p)),
        _ => Err(format!("No next strict pointer in {:?}", app)),
    }
}

fn vec_to_app(v: Vec<Atom>) -> App {
    assert!(v.len() <= APP_LENGTH);
    let mut res: App = std::array::from_fn(|_| Atom::Nop);
    v.iter().enumerate().for_each(|(i, a)| res[i] = *a);
    res
}

/// Dereference `app`'s PTR at position `arg_id`, with `target`
/// - when returning `(app, None)`, `app` is the deref result
/// - when returning `(app1, Some(app2))`,
///   `app1` is the deref result,
///   `app2` goes to port b
fn deref(app: &App, arg_id: usize, target: &App, free_addr: usize) -> (App, Option<App>) {
    debug_assert!(is_ptr(&app[arg_id]));

    // Seq(false) never touches target, handle first, skip dash_app entirely.
    // if let Atom::Seq = app[0] {
    //     let mut res = *app; // Copy, not clone — no alloc
    //     if arg_id == 1 {
    //         res[0] = Atom::Seq(true);
    //     }
    //     return (res, None);
    // }

    let unique = matches!(app[arg_id], Atom::Ptr(_, true, _));
    let dashed_storage; // holds owned value if needed
    let target_dashed: &App = if unique {
        target
    } else {
        dashed_storage = dash_app(target);
        &dashed_storage
    };
    let app_len = app_length(app);
    let target_len = app_length(target);

    // Write straight into a stack buffer with a cursor.
    let mut buf = [Atom::default(); 2 * APP_LENGTH];
    let mut n = 0;
    let mut push = |src: &[Atom]| {
        buf[n..n + src.len()].copy_from_slice(src);
        n += src.len();
    };

    match app[0] {
        Atom::Seq /*| Atom::Try*/ => {
            push(&app[2..app_len]);
        }
        _ => {
            push(&app[0..arg_id]);
            push(&target_dashed[0..target_len]);
            push(&app[arg_id + 1..app_len]);
        }
    }
    let res = &buf[..n];

    if n <= APP_LENGTH {
        (slice_to_app(res), None)
    } else {
        // write-back: prepend the pointer
        let mut wb = [Atom::default(); APP_LENGTH];
        wb[0] = Atom::Ptr(free_addr, true, false);
        wb[1..1 + (n - APP_LENGTH)].copy_from_slice(&res[APP_LENGTH..]);
        (
            slice_to_app(&wb[..1 + (n - APP_LENGTH)]),
            Some(slice_to_app(&res[0..APP_LENGTH])),
        )
    }
}

fn slice_to_app(s: &[Atom]) -> App {
    debug_assert!(s.len() <= APP_LENGTH);
    let mut a = [Atom::Nop; APP_LENGTH];
    a[..s.len()].copy_from_slice(s);
    a
}

#[test]
fn deref_spec() {
    use Atom::*;
    let app: App = [
        Ptr(0, true, false),
        Int(1),
        Ptr(2, true, false),
        Int(3),
        Nop,
        Nop,
        Nop,
        Nop,
    ];
    let target1: App = [
        Ptr(11, true, false),
        Ptr(22, true, false),
        Ptr(33, true, false),
        Ptr(44, true, false),
        Ptr(55, true, false),
        Nop,
        Nop,
        Nop,
    ];
    let target2: App = [
        Ptr(11, true, false),
        Ptr(22, true, false),
        Ptr(33, true, false),
        Ptr(44, true, false),
        Ptr(55, true, false),
        Ptr(66, true, false),
        Ptr(77, true, false),
        Nop,
    ];
    let res1: App = [
        Ptr(0, true, false),
        Int(1),
        Ptr(11, true, false),
        Ptr(22, true, false),
        Ptr(33, true, false),
        Ptr(44, true, false),
        Ptr(55, true, false),
        Int(3),
    ];
    let res2_1: App = [
        Ptr(11, true, false),
        Ptr(22, true, false),
        Ptr(33, true, false),
        Ptr(44, true, false),
        Ptr(55, true, false),
        Ptr(66, true, false),
        Ptr(77, true, false),
        Int(1),
    ];
    let res2_2: App = [
        Ptr(42, true, false),
        Ptr(2, true, false),
        Int(3),
        Nop,
        Nop,
        Nop,
        Nop,
        Nop,
    ];
    assert_eq!(deref(&app, 2, &target1, 42), (res1, None));
    assert_eq!(deref(&app, 0, &target2, 42), (res2_2, Some(res2_1)));
}

impl fmt::Display for Stm {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            Stm::Idle => write!(f, "IDLE"),
            Stm::Whnf => write!(f, "WHNF"),
            Stm::Ia => write!(f, "IA"),
            Stm::Resume => write!(f, "RESUME"),
        }
    }
}

pub struct DrfHeap {
    pub input: DrfHeapInput,
    stm: Register<Stm>,
    holder_in: Register<ActiveApp>,
    addr_holder: Register<usize>,
    ia_addr: Register<usize>,
    thread_stack: [AddrStack; MAX_THREADS],
    frame_stack: [FrameStack; MAX_THREADS],
    pub heap_mem: DualPortMem<App>,
    working_heap: DualPortMem<bool>,
    holder_out: (bool, ActiveApp), // output-reg: (valid, app)
    holder_out_startup: bool,
    io_holder: (bool, ActiveApp), // ready IO request, held until accepted
    working: Register<bool>,       // track whether the machine is working
    arg_id: Register<usize>,
    non_exist: Register<bool>,
    gc_read_granted: Register<bool>,
    reg_free_addr: Register<(bool, usize)>,
    stat: DrfHeapStat,
    stat_detail_lv: u8,
}

impl DrfHeap {
    pub fn new(heap_size: usize) -> Self {
        Self {
            input: Default::default(),
            stm: Default::default(),
            holder_in: Default::default(),
            addr_holder: Default::default(),
            ia_addr: Default::default(),
            thread_stack: std::array::from_fn(|_| Stack::new()),
            frame_stack: std::array::from_fn(|_| Stack::new()),
            heap_mem: DualPortMem::new(heap_size),
            working_heap: DualPortMem::new(heap_size),
            holder_out: Default::default(),
            holder_out_startup: false,
            io_holder: Default::default(),
            working: Default::default(),
            stat: Default::default(),
            arg_id: Default::default(),
            non_exist: Default::default(),
            gc_read_granted: Default::default(),
            reg_free_addr: Default::default(),
            stat_detail_lv: Default::default(),
        }
    }

    /// When creating a `DrfHeap`, put a compiled program into the heap memory.
    pub fn program(mut self, prog: &Vec<Vec<Atom>>) -> Self {
        fn convert(atms: &Vec<Atom>) -> App {
            assert!(atms.len() <= APP_LENGTH);
            let mut app: App = std::array::from_fn(|_| Atom::Nop);
            for (i, atm) in atms.iter().enumerate() {
                app[i] = *atm;
            }
            app
        }
        // convert Vec<Vec<Atom>> to Vec<HeapCell>
        let img: Vec<App> = prog.iter().map(convert).collect();
        self.heap_mem.image(&img);
        self
    }

    /// Setup the detail level of stats, 0~lowest, 255~highest
    pub fn detail(mut self, lv: u8) -> Self {
        self.stat_detail_lv = lv;
        self.heap_mem.record_stat = lv >= DLV_MEM_USAGE;
        self
    }

    pub fn port_a_fire(&self) -> bool {
        fire(self.input.port_a_valid, self.port_a_ready())
    }

    pub fn port_b_fire(&self) -> bool {
        fire(self.input.port_b_valid, self.port_b_ready())
    }

    pub fn output_fire(&self) -> bool {
        fire(self.out_main_valid(), self.input.out_main_ready)
    }

    pub fn out_sub_fire(&self) -> bool {
        fire(self.out_sub_valid(), self.input.out_sub_ready)
    }

    pub fn out_io_valid(&self) -> bool {
        self.io_holder.0
    }

    pub fn out_io_bits(&self) -> &ActiveApp {
        &self.io_holder.1
    }

    pub fn out_io_fire(&self) -> bool {
        fire(self.out_io_valid(), self.input.out_io_ready)
    }

    pub fn port_a_ready(&self) -> bool {
        let local_release: bool = match *self.stm.value() {
            Stm::Idle => true,
            Stm::Whnf => matches!(self.get_whnfs(), WHNFs::NoNewFrame),
            Stm::Ia => {
                let ias1 = self.get_ias1();
                match self.get_ias2(&ias1) {
                    IAs2::NoMoreArgsCanEmit | IAs2::NoMoreArgsNoEmit => !self.is_sensitive(&ias1),
                    _ => false,
                }
            }
            Stm::Resume => match self.get_resumes() {
                RESUMEs::TopInWHNF => false,
                RESUMEs::TopInIA => true,
            },
        };
        // Do not accept another ready request while a previous IO effect is
        // backpressured. It must leave the holder exactly once.
        local_release && self.input.free_addr_valid
            && (!self.io_holder.0 || self.input.out_io_ready)
            && (!self.out_main_valid() || self.input.out_main_ready)
    }

    pub fn port_b_ready(&self) -> bool {
        let borrowed: bool = match *self.stm.value() {
            Stm::Idle => false,
            Stm::Whnf => match self.get_whnfs() {
                WHNFs::MoreDmders | WHNFs::NewFrame => false,
                WHNFs::NoNewFrame => !self.can_avoid_update(),
            },
            Stm::Ia => {
                let ias1 = self.get_ias1();
                match self.get_ias2(&ias1) {
                    IAs2::NoMoreArgsNoEmit => true,
                    // IAs2::NoMoreArgsCanEmit => ias1 == IAs1::ExistWHNF && self.need_split(),
                    _ => false,
                }
            }
            Stm::Resume => true,
        };
        !borrowed
    }

    /// Only the initial root bypasses DHeap's input processing. It must not
    /// issue an IO request directly from this startup holder.
    pub fn out_main_from_startup(&self) -> bool {
        self.holder_out.0 && self.holder_out_startup
    }

    pub fn out_main_valid(&self) -> bool {
        let derived: bool = {
            match *self.stm.value() {
                Stm::Idle => false,
                Stm::Whnf => true,
                Stm::Ia => {
                    let ias1 = self.get_ias1();
                    if ias1 == IAs1::ExistIAFresh {
                        return true;
                    }
                    matches!(self.get_ias2(&ias1), IAs2::NoMoreArgsCanEmit)
                }
                Stm::Resume => false,
            }
        };
        self.holder_out.0 || derived
    }

    pub fn out_main_bits(&self) -> Result<ActiveApp, String> {
        let target = self.heap_mem.dout_a();
        if self.holder_out.0 {
            return Ok(self.holder_out.1.clone());
        }

        match *self.stm.value() {
            Stm::Idle => Ok(Default::default()),
            Stm::Whnf => {
                let (deref_res, _) = self.gen_output_whnf()?;
                Ok(self.gen_active_app(deref_res))
            }
            Stm::Ia => {
                let ias1 = self.get_ias1();
                if ias1 == IAs1::ExistIAFresh {
                    return Ok(self.gen_active_app(self.dash_when_shared()));
                }
                match self.get_ias2(&ias1) {
                    IAs2::NoMoreArgsCanEmit => {
                        check_io_target(&self.holder_in.value().load, *self.arg_id.value(), target)?;
                        let (updated_dmder, _) = deref(
                            &self.holder_in.value().load,
                            *self.arg_id.value(),
                            target,
                            // self.input.free_addr,
                            self.reg_free_addr.value().1,
                        );
                        Ok(self.gen_active_app(updated_dmder))
                    }
                    _ => Ok(Default::default()),
                }
            }
            Stm::Resume => Ok(Default::default()),
        }
    }

    pub fn out_sub_valid(&self) -> bool {
        self.port_b_fire() && self.waited_by().is_some()
    }

    pub fn out_sub_bits(&self) -> ActiveApp {
        let load = extend_to_app(&self.input.port_b_bits.load);
        ActiveApp {
            stack_idx: self.find_dmder_stk(),
            load: dash_app(&load),
        }
    }

    pub fn out_big_drf_valid(&self) -> bool {
        self.need_split()
    }

    pub fn out_big_drg_bits(&self) -> Result<FrozenApp, String> {
        let mk_frozen = |a: Option<App>| match a {
            Some(big) => FrozenApp {
                // heap_addr: self.input.free_addr,
                heap_addr: self.reg_free_addr.value().1,
                load: big,
            },
            None => Default::default(),
        };

        Ok(match *self.stm.value() {
            Stm::Whnf => mk_frozen(self.gen_output_whnf()?.1),
            Stm::Ia if self.get_ias1() == IAs1::ExistWHNF => {
                let dmder = &self.holder_in.value().load;
                let target = self.heap_mem.dout_a();
                // let (_, obig) = deref(dmder, *self.arg_id.value(), target, self.input.free_addr);
                let (_, obig) = deref(
                    dmder,
                    *self.arg_id.value(),
                    target,
                    self.reg_free_addr.value().1,
                );
                mk_frozen(obig)
            }
            _ => Default::default(),
        })
    }

    /// Deallocate an address based on one-bit ref count
    pub fn dealloc_valid(&self) -> bool {
        // NOTE should do this *on return* or *on deref*?
        // ready signal does not block DHeap, giving up some chances is fine
        (*self.stm.value() == Stm::Whnf
            && self.get_whnfs() == WHNFs::NoNewFrame
            && self.can_avoid_update())
            || (*self.stm.value() == Stm::Ia
                && self.get_ias1() == IAs1::ExistIAFresh
                && self.can_forward())
    }

    /// Deallocate an address based on one-bit ref count
    pub fn dealloc_bits(&self) -> usize {
        *self.addr_holder.value()
    }

    /// machine's work has been finished
    pub fn done(&self) -> bool {
        !self.working.value()
    }

    /// search for the addr of the App, which is currently being read by DHeap
    pub fn search(&self) -> Result<usize, String> {
        if self.port_a_fire() && self.get_consumes()? == CONSUMEs::InputIA {
            let in_app = mask_seq(&self.input.port_a_bits.load);
            // println!(
            //     "stack id : {} addr: {:?}",
            //     self.input.port_a_bits.stack_idx,
            //     self.thread_stack[self.input.port_a_bits.stack_idx as usize].top()
            // );
            let (_, p) = select_1st_arg(&in_app)?;
            Ok(p)
        } else if *self.stm.value() == Stm::Ia {
            match self.get_ias2(&self.get_ias1()) {
                IAs2::NextStrictArgLocal | IAs2::NextStrictArgNewStk => {
                    let dmder = &self.holder_in.value().load;
                    let (_, p) = select_next_arg(dmder, *self.arg_id.value())?;
                    Ok(p)
                }
                _ => Ok(0),
            }
        } else {
            Ok(0)
        }
    }

    /// feedback signal on when the free addr is used
    pub fn free_addr_feedback(&self) -> usize {
        self.reg_free_addr.value().1
    }

    pub fn get_stat(&self) -> &DrfHeapStat {
        &self.stat
    }

    pub fn get_mem_stat(&self) -> &DualPortMemStat {
        self.heap_mem.get_stat()
    }

    pub fn heap_read_valid(&self) -> bool {
        *self.gc_read_granted.value()
    }

    pub fn heap_read_bits(&self) -> &App {
        self.heap_mem.dout_b()
    }

    fn get_consumes(&self) -> Result<CONSUMEs, String> {
        if !self.port_a_fire() {
            Ok(CONSUMEs::NoInput)
        } else if io_is_ready(&self.input.port_a_bits.load) {
            Ok(CONSUMEs::InputIOReady)
        } else if is_con(&self.input.port_a_bits.load[0])
            && !is_whnf(&self.input.port_a_bits.load) {
            // An over-applied IO result arrives from the IO unit through
            // port A. Reducer-ready constructors have no strict operands.
            Ok(CONSUMEs::InputForwardReducer)
        } else {
            let stk = &self.thread_stack[self.input.port_a_bits.stack_idx as usize];
            if is_whnf(&self.input.port_a_bits.load) {
                if self
                    .thread_stack
                    .iter()
                    .any(find_more_dmder(stk.top().unwrap().1))
                {
                    Ok(CONSUMEs::InputWHNFWithDmder)
                } else {
                    if stk.second().is_some() {
                        if stack_cell_with(stk.second(), |(flag, _)| !*flag) {
                            return Err("strange new frame!".to_string());
                        }
                        Ok(CONSUMEs::InputWHNFNoDmderNewFrame)
                    } else {
                        Ok(CONSUMEs::InputWHNFNoDmderNoFrame)
                    }
                }
            } else {
                Ok(CONSUMEs::InputIA)
            }
        }
    }

    fn get_whnfs(&self) -> WHNFs {
        if self
            .thread_stack
            .iter()
            .any(find_more_dmder(*self.addr_holder.value()))
        {
            WHNFs::MoreDmders
        } else {
            if self
                .thread_stack
                .iter()
                .any(find_new_frame(*self.addr_holder.value()))
            {
                WHNFs::NewFrame
            } else {
                WHNFs::NoNewFrame
            }
        }
    }

    fn get_ias1(&self) -> IAs1 {
        let target = self.heap_mem.dout_a();
        let stk = &self.thread_stack[self.holder_in.value().stack_idx as usize];
        if *self.non_exist.value() {
            IAs1::NoExist
        } else {
            if is_whnf(target) {
                IAs1::ExistWHNF
            } else {
                if !*self.working_heap.dout_a() {
                    IAs1::ExistIAFresh
                } else {
                    if stack_cell_with(stk.top(), |(flag, _)| !*flag) {
                        IAs1::ExistIAWorkingNormal
                    } else {
                        IAs1::ExistIAWorkingAtNewFrame
                    }
                }
            }
        }
    }

    fn get_ias2(&self, s1: &IAs1) -> IAs2 {
        let ia = &self.holder_in.value().load;
        let target_in_whnf = !*self.non_exist.value() && is_whnf(self.heap_mem.dout_a());
        // if let None = self.frame_stack[self.holder_in.value().stack_idx as usize].top() {
        //     println!(
        //         "Sick. holder_in: {:?}, \n stack: {:?} \n frame_stk: {:?}",
        //         self.holder_in.value(),
        //         self.thread_stack[self.holder_in.value().stack_idx as usize].mem,
        //         self.frame_stack[self.holder_in.value().stack_idx as usize].mem
        //     );
        // }
        let frame_record = self.frame_stack[self.holder_in.value().stack_idx as usize]
            .top()
            .unwrap();
        let idle_stack: bool = self
            .thread_stack
            .iter()
            .enumerate()
            .any(|(idx, s)| find_free_stack(s, frame_record[idx]));
        let local_stack: bool = *s1 == IAs1::ExistWHNF || *s1 == IAs1::ExistIAWorkingAtNewFrame; // NOTE
        let more_strict_args: bool = {
            match ia[0] {
                Atom::Ptr(_, _, _) | Atom::Seq => false,
                Atom::Prm(_, _) => *self.arg_id.value() == 1 && is_ptr(&ia[2]),
                Atom::Try => *self.arg_id.value() == 1 && *s1 != IAs1::ExistWHNF,
                Atom::IO(_) => io_next_pointer(ia, *self.arg_id.value()).is_some(),
                // more on this to support strict args in the future
                _ => unreachable!(),
            }
        };

        // IO operands must be forced in order. Unlike pure PRM arguments,
        // concurrent forcing would permit a later World/data dependency to
        // resume before the earlier argument and confuse the ordinary
        // demander-heap unwinding path (which selects the first unresolved PTR).
        // We still use the normal suspension/reactivation mechanism.
        if is_io(&ia[0]) && more_strict_args && *s1 != IAs1::ExistWHNF {
            IAs2::NoMoreArgsNoEmit
        } else if more_strict_args && local_stack {
            IAs2::NextStrictArgLocal
        } else if more_strict_args && idle_stack {
            IAs2::NextStrictArgNewStk
        } else {
            if (is_ptr(&ia[0])
                || (is_prm(&ia[0]) && (is_int(&ia[1]) || is_int(&ia[2])))
                || is_seq(&ia[0])
                || (is_try(&ia[0]) && *self.arg_id.value() == 1)
                || is_io(&ia[0]))
                && target_in_whnf
            {
                IAs2::NoMoreArgsCanEmit
            } else {
                IAs2::NoMoreArgsNoEmit // TRY second should go here; what if the 2nd is in compute? We can use meta data to improve PRM/SEQ/TRY?
            }
        }
    }

    fn get_resumes(&self) -> RESUMEs {
        let top = self.heap_mem.dout_a();
        if is_whnf(top) {
            RESUMEs::TopInWHNF
        } else {
            RESUMEs::TopInIA
        }
    }

    /// check whether the app on port b is being waited by any thread
    fn waited_by(&self) -> Option<usize> {
        let addr = self.input.port_b_bits.heap_addr;
        let a_thread = self.holder_in.value().stack_idx as usize;
        if *self.stm.value() == Stm::Ia
            && self.get_ias1() == IAs1::NoExist
            && *self.addr_holder.value() == addr
        {
            Some(a_thread)
        } else {
            self.thread_stack
                .iter()
                .position(|s| stack_cell_with(s.top(), |(_, a)| *a == addr))
        }
    }

    /// preparations in each `update_local`
    fn update_prepare(&mut self) {
        // always give default inputs at the beginning of a cycle
        self.heap_mem.input.default_input();
        self.working_heap.input.default_input();
        for stk in &mut self.thread_stack {
            stk.input.default_input();
        }
        for stk in &mut self.frame_stack {
            stk.input.default_input();
        }

        // clear holder when output fires
        if self.output_fire() {
            self.holder_out.0 = false;
            self.holder_out_startup = false;
        }
        if self.out_io_fire() {
            self.io_holder.0 = false;
        }
    }

    /// read the pointed target
    fn read_target(&mut self, p: usize) {
        self.heap_mem.read_a(p);
        self.working_heap.read_a(p);
        self.addr_holder.connect(&p);
    }

    /// write the incoming app
    fn write_incoming(&mut self, p: HeapPort) {
        let current_stk = &mut self.thread_stack[self.input.port_a_bits.stack_idx as usize];
        let addr = current_stk.top().unwrap().1;
        let cell = dash_app(&self.input.port_a_bits.load);
        current_stk.pop();
        match p {
            HeapPort::A => self.heap_mem.write_a(addr, cell),
            HeapPort::B => self.heap_mem.write_b(addr, cell),
        }
        self.working_heap.write_a(addr, false); // for future re-allocation
    }

    /// write the incoming WHNF
    fn write_whnf(&mut self, p: HeapPort) {
        let addr = *self.addr_holder.value();
        let cell = dash_app(&self.holder_in.value().load);
        match p {
            HeapPort::A => self.heap_mem.write_a(addr, cell),
            HeapPort::B => self.heap_mem.write_b(addr, cell),
        }
        self.working_heap.write_b(addr, false); // for future re-allocation
    }

    /// when sub port is firing, find which stack is demanding the app
    fn find_dmder_stk(&self) -> u8 {
        if let Some(i) = self.waited_by() {
            i as u8
        } else {
            0
        }
    }

    /// find the stack that satisfies `p`, pop the stack and read the second item
    fn find_pop_read(&mut self, p: impl Fn(&AddrStack) -> bool, pop_frame: bool) {
        if let Some((stk_id, stack)) = self.thread_stack.iter_mut().enumerate().find(|(_, s)| p(s))
        {
            stack.pop();
            // if pop_frame {
            //     self.frame_stack[stk_id].pop();
            //     if stk_id == 3 {
            //         println!("frame stk 3 popped. P1");
            //     }
            // }
            self.heap_mem.read_a(stack.second().unwrap().1);
            self.holder_in.input.stack_idx = stk_id as u8;
        } else {
            unreachable!()
        }
    }

    /// select first arg from `app` and read it
    fn select_1st_arg_read(&mut self, app: &App) -> Result<(), String> {
        let (arg_id, p) = select_1st_arg(app)?;
        self.read_target(p);
        self.arg_id.connect(&(arg_id as usize));
        Ok(())
    }

    /// select next arg from `app` and read it
    fn select_next_arg_read(&mut self, app: &App) -> Result<(), String> {
        let (arg_id, p) = select_next_arg(app, *self.arg_id.value())?;
        self.read_target(p);
        self.arg_id.connect(&arg_id);
        Ok(())
    }

    /// push the target, set its working flag
    fn push_target(&mut self, new_frame: bool) {
        let current_stk = &mut self.thread_stack[self.holder_in.value().stack_idx as usize];
        self.working_heap.write_b(*self.addr_holder.value(), true);
        current_stk.push((new_frame, *self.addr_holder.value()));
    }

    /// ''sensitive'' cases:
    /// 1. we push an item to wait for an app, but that app is returning in this cycle
    /// 2. we ride on an idle stack, but the old waited app is returning in this cycle
    fn is_sensitive(&self, s1: &IAs1) -> bool {
        let sensitive1 = *s1 == IAs1::ExistIAWorkingNormal;
        let sensitive2 = *s1 == IAs1::ExistIAFresh || *s1 == IAs1::NoExist;
        let returning_app = self.thread_stack[self.input.port_a_bits.stack_idx as usize]
            .top()
            .unwrap()
            .1;
        let current_stk = &self.thread_stack[self.holder_in.value().stack_idx as usize];
        let same1 = returning_app == *self.addr_holder.value();
        let same2 = stack_cell_with(current_stk.top(), |(_, addr)| *addr == returning_app);
        (sensitive1 && same1) || (sensitive2 && same2)
    }

    /// take shortcuts, unless 'sensitive cases' are encountered
    fn step_to_next(&mut self, s1: &IAs1) -> Result<(), String> {
        if self.is_sensitive(s1) {
            self.stm.connect(&Stm::Idle);
        } else {
            self.consume_next()?;
        }

        Ok(())
    }

    fn gen_output_whnf(&self) -> Result<(App, Option<App>), String> {
        let dmder = self.heap_mem.dout_a();
        let target = &self.holder_in.value().load;
        // println!("addr: {}", self.heap_mem.input.port_a.addr); // use this for GC debugging
        let (arg_id, _) = select_1st_arg(dmder)?;
        check_io_target(dmder, arg_id, target)?;

        Ok(deref(
            dmder,
            arg_id,
            target,
            self.reg_free_addr.value().1,
        ))
    }

    fn gen_active_app(&self, app: App) -> ActiveApp {
        ActiveApp {
            stack_idx: self.holder_in.value().stack_idx,
            load: app,
        }
    }

    fn gen_frame_record(&self) -> FrameRecord {
        let father_stk_id = self.holder_in.value().stack_idx as usize;
        let mut res = *self.frame_stack[father_stk_id].top().unwrap();
        res[father_stk_id] = self.addr_holder.input;
        res
    }

    /// if currently in a new frame & not pushing, cancel the new frame
    fn cancel_new_frame(&mut self, s1: &IAs1) {
        match s1 {
            IAs1::ExistWHNF | IAs1::ExistIAWorkingAtNewFrame => {
                let stk_idx = self.holder_in.value().stack_idx as usize;
                let stk = &self.thread_stack[stk_idx];
                // problem 1: this empty stack should also be cancelled
                if stack_cell_with(stk.top(), |(flag, _)| *flag) {
                    self.frame_stack[stk_idx].pop();
                    // if stk_idx == 3 {
                    //     println!(
                    //         "ias1: {:?} holder: {:?} frame stk 3 popped. P2, stack-top: {:?}",
                    //         s1,
                    //         self.holder_in.value(),
                    //         self.thread_stack[stk_idx].top()
                    //     );
                    // }
                }
            }
            _ => {}
        }
    }

    pub fn need_split(&self) -> bool {
        match self.stm.value() {
            Stm::Idle => false,
            Stm::Whnf => {
                let dmder = self.heap_mem.dout_a();
                let target = &self.holder_in.value().load;
                app_length(dmder) + app_length(target) - 1 > APP_LENGTH
            }
            Stm::Ia => match self.get_ias1() {
                IAs1::ExistWHNF => {
                    let dmder = &self.holder_in.value().load;
                    let target = self.heap_mem.dout_a();
                    app_length(dmder) + app_length(target) - 1 > APP_LENGTH
                }
                _ => false,
            },
            Stm::Resume => false,
        }
    }

    /// request a free addr from the addr box
    pub fn free_addr_req(&self) -> bool {
        self.need_split() || !self.reg_free_addr.value().0
    }

    /// for GC stats
    fn stalled(&self) -> bool {
        let local_release: bool = match *self.stm.value() {
            Stm::Idle => true,
            Stm::Whnf => matches!(self.get_whnfs(), WHNFs::NoNewFrame),
            Stm::Ia => {
                let ias1 = self.get_ias1();
                match self.get_ias2(&ias1) {
                    IAs2::NoMoreArgsCanEmit | IAs2::NoMoreArgsNoEmit => !self.is_sensitive(&ias1),
                    _ => false,
                }
            }
            Stm::Resume => match self.get_resumes() {
                RESUMEs::TopInWHNF => false,
                RESUMEs::TopInIA => true,
            },
        };
        local_release && !self.input.free_addr_valid
    }

    /// if the resolved pointer is unique, update can be avoided
    fn can_avoid_update(&self) -> bool {
        // return false;
        match self.heap_mem.dout_a()[0] {
            Atom::Ptr(_, true, _) => true,
            Atom::Prm(_, _) => match &self.heap_mem.dout_a()[1] {
                Atom::Ptr(_, unique, _) => *unique,
                _ => matches!(&self.heap_mem.dout_a()[2], Atom::Ptr(_, true, _)),
            },
            Atom::IO(_) => {
                let dmder = self.heap_mem.dout_a();
                io_next_pointer(dmder, 0)
                    .map(|(idx, _)| is_unique_ptr(&dmder[idx]))
                    .unwrap_or(false)
            }
            Atom::Seq => match &self.heap_mem.dout_a()[1] {
                Atom::Ptr(_, unique, _) => *unique,
                _ => false,
            },
            _ => false,
        }
    }

    fn dash_when_shared(&self) -> App {
        let dmder = &self.holder_in.value().load;
        let target = self.heap_mem.dout_a();
        if is_unique_ptr(&dmder[*self.arg_id.value()]) {
            *target
        } else {
            dash_app(target)
        }
    }

    fn can_forward(&self) -> bool {
        app_length(&self.holder_in.value().load) == 1
            && matches!(self.holder_in.value().load[0], Atom::Ptr(_, true, _))
    }

    /// consumes the next task; must not use heap port b!
    fn consume_next(&mut self) -> Result<(), String> {
        let in_app = mask_seq(&self.input.port_a_bits.load);
        self.holder_in.connect(&ActiveApp {
            stack_idx: self.input.port_a_bits.stack_idx,
            load: in_app,
        });

        match self.get_consumes()? {
            CONSUMEs::NoInput => self.stm.connect(&Stm::Idle),
            CONSUMEs::InputIOReady => {
                // No stack pop or heap update: the app is still under evaluation
                // until the IO unit sends the completed Pair back via port_a.
                debug_assert!(!self.io_holder.0);
                self.io_holder = (true, self.input.port_a_bits.clone());
                self.stm.connect(&Stm::Idle);
            }
            CONSUMEs::InputForwardReducer => {
                debug_assert!(!self.holder_out.0);
                self.holder_out = (true, self.input.port_a_bits.clone());
                self.holder_out_startup = false;
                self.stm.connect(&Stm::Idle);
            }
            CONSUMEs::InputIA => {
                self.select_1st_arg_read(&in_app)?;
                self.ia_addr.connect(
                    &self.thread_stack[self.input.port_a_bits.stack_idx as usize]
                        .top()
                        .unwrap()
                        .1,
                );
                self.stm.connect(&Stm::Ia);
            }
            CONSUMEs::InputWHNFWithDmder => {
                let current_stk = &self.thread_stack[self.input.port_a_bits.stack_idx as usize];
                let current_top = current_stk.top().unwrap().1;
                self.find_pop_read(find_more_dmder(current_top), false);
                self.addr_holder.connect(&current_top);
                self.stm.connect(&Stm::Whnf);
            }
            CONSUMEs::InputWHNFNoDmderNewFrame => {
                let current_stk = &mut self.thread_stack[self.input.port_a_bits.stack_idx as usize];
                let current_top = current_stk.top().unwrap().1;
                current_stk.pop();
                self.heap_mem.read_a(current_stk.second().unwrap().1);
                self.addr_holder.connect(&current_top);
                self.frame_stack[self.input.port_a_bits.stack_idx as usize].pop();
                // if self.input.port_a_bits.stack_idx as usize == 3 {
                //     println!("frame stk 3 popped. P3");
                // }
                self.stm.connect(&Stm::Resume);
            }
            CONSUMEs::InputWHNFNoDmderNoFrame => {
                self.frame_stack[self.input.port_a_bits.stack_idx as usize].pop();
                // if self.input.port_a_bits.stack_idx as usize == 3 {
                //     println!("frame stk 3 popped. P4");
                // }
                self.write_incoming(HeapPort::A);
                self.stm.connect(&Stm::Idle);
            }
        }
        Ok(())
    }

    fn step_whnf(&mut self) -> Result<(), String> {
        let whnf_addr = *self.addr_holder.value();

        match self.get_whnfs() {
            WHNFs::MoreDmders => {
                self.find_pop_read(find_more_dmder(whnf_addr), false);
                self.stm.connect(&Stm::Whnf);
            }
            WHNFs::NewFrame => {
                // don't need to write WHNF here, since RESUME will do
                self.find_pop_read(find_new_frame(whnf_addr), true);
                self.stm.connect(&Stm::Resume);
                self.stat.heap_update += 1;
            }
            WHNFs::NoNewFrame => {
                if let Some((stk_id, stack)) = self
                    .thread_stack
                    .iter_mut()
                    .enumerate()
                    .find(|(_, s)| stack_cell_with(s.top(), |(_, addr)| *addr == whnf_addr))
                {
                    // pop when the whnf is the last item on that stack
                    stack.pop();
                    self.frame_stack[stk_id].pop();
                    // if stk_id == 3 {
                    //     println!("frame stk 3 popped. P5");
                    // }
                }

                /*
                NOTE problem here: upon WHNF's return, we don't update the demander on heap.
                If we deallocate the WHNF, a pointer to that WHNF is still on heap..

                This should be fine, as free cells in marking will be ignored..
                 */
                if self.can_avoid_update() {
                    /* update avoided */
                    self.stat.update_avoided += 1;
                    self.working_heap.write_b(whnf_addr, false); // for future re-allocation
                } else {
                    self.stat.heap_update += 1;
                    self.write_whnf(HeapPort::B);
                }
                self.consume_next()?;
            }
        }
        Ok(())
    }

    fn step_ia(&mut self) -> Result<(), String> {
        let dmder = &self.holder_in.value().load;
        let mut updated_dmder = *dmder;
        let target = *self.heap_mem.dout_a();
        let ias1 = self.get_ias1();

        match ias1 {
            IAs1::NoExist => {
                self.push_target(false);
            }
            IAs1::ExistWHNF => {
                check_io_target(dmder, *self.arg_id.value(), &target)?;
                let (deref_res, _) =
                    deref(dmder, *self.arg_id.value(), &target, self.reg_free_addr.value().1);
                updated_dmder = deref_res;
                self.holder_in.input.load = updated_dmder;
            }
            IAs1::ExistIAWorkingNormal => {
                // change this to `self.push_target(false);` will disable stack riding
                self.push_target(true);
                // if self.holder_in.value().stack_idx == 3 {
                //     println!(
                //         "push new_frame when ias2: {:?}, holder: {:?}",
                //         self.getIAs2(&ias1),
                //         self.holder_in.value()
                //     );
                // }
            }
            IAs1::ExistIAWorkingAtNewFrame => { /* do nothing here */ }
            IAs1::ExistIAFresh => {
                if !self.can_forward() {
                    self.push_target(false);
                }
            }
        }

        match self.get_ias2(&ias1) {
            IAs2::NextStrictArgNewStk => {
                let current_idx = self.holder_in.value().stack_idx as usize;
                self.select_next_arg_read(&updated_dmder)?;
                let frame_record = self.frame_stack[current_idx].top().unwrap();
                if let Some((stk_id, _)) = self
                    .thread_stack
                    .iter()
                    .enumerate()
                    .find(|(idx, s)| find_free_stack(s, frame_record[*idx]))
                {
                    // FIXME: ensure using a new stack
                    if stk_id as u8 == self.holder_in.value().stack_idx {
                        return Err("GOT YA!".to_string());
                    }
                    self.holder_in.input.stack_idx = stk_id as u8;
                    self.frame_stack[stk_id].push(self.gen_frame_record());
                };
            }
            IAs2::NextStrictArgLocal => {
                self.select_next_arg_read(&updated_dmder)?;
            }
            IAs2::NoMoreArgsNoEmit => {
                self.cancel_new_frame(&ias1);
                self.heap_mem.write_b(*self.ia_addr.value(), updated_dmder);
                self.step_to_next(&ias1)?;
            }
            IAs2::NoMoreArgsCanEmit => {
                self.cancel_new_frame(&ias1);
                self.step_to_next(&ias1)?;
            }
        }
        Ok(())
    }

    fn step_resume(&mut self) -> Result<(), String> {
        self.write_whnf(HeapPort::B);
        match self.get_resumes() {
            RESUMEs::TopInWHNF => {
                let current_stk = &mut self.thread_stack[self.holder_in.value().stack_idx as usize];
                let whnf_addr = current_stk.top().unwrap().1;
                let dmder_addr = current_stk.second().unwrap().1;
                self.holder_in.input.load = *self.heap_mem.dout_a();
                current_stk.pop();
                self.heap_mem.read_a(dmder_addr);
                self.addr_holder.connect(&whnf_addr);
                self.stm.connect(&Stm::Whnf);
            }
            RESUMEs::TopInIA => {
                self.consume_next()?;
            }
        }
        Ok(())
    }

    fn handle_port_a(&mut self) -> Result<(), String> {
        if (self.out_main_valid() && !self.input.out_main_ready)
            || (self.io_holder.0 && !self.input.out_io_ready)
        {
            return Ok(());
        }

        match *self.stm.value() {
            Stm::Idle => self.consume_next(),
            Stm::Whnf => self.step_whnf(),
            Stm::Ia => self.step_ia(),
            Stm::Resume => self.step_resume(),
        }
    }

    fn handle_port_b(&mut self) {
        if self.port_b_fire() {
            let addr = self.input.port_b_bits.heap_addr;
            let app = extend_to_app(&self.input.port_b_bits.load);
            self.heap_mem.write_b(addr, app);

            // if addr == 4060 {
            //     if let Some(3) = self.waited_by() {
            //         println!("4060 from sub emit: {:?}", self.input.port_b_bits);
            //     }
            // }
        }
    }
}

impl HwModule for DrfHeap {
    fn update_local(&mut self) -> Result<(), String> {
        self.update_prepare();
        self.gc_read_granted.connect(&false);

        // start the machine (demand flag of `main`, at addr 0, need to be false.)
        if !self.working.value() {
            if self.input.start {
                self.working.connect(&true);
                // push to stack
                self.thread_stack[0].push((false, 0));
                self.frame_stack[0].push(Default::default());
                // put output register
                self.holder_out_startup = true;
                self.holder_out = (
                    true,
                    ActiveApp {
                        stack_idx: 0,
                        load: *self.heap_mem.dout_a(),
                    },
                );
            }
            return Ok(());
        }
        // stop the machine when finished
        if self.port_a_fire() {
            // if its main in WHNF
            if self.thread_stack[0].elements() == 1
                && self.input.port_a_bits.stack_idx == 0
                && is_whnf(&self.input.port_a_bits.load)
            {
                self.working.connect(&false);
                return Ok(());
            }
        }
        self.non_exist.connect(&self.input.found);

        self.handle_port_a()?;
        self.handle_port_b();

        // when port b is not locally used, grant it to GC usage
        if self.port_b_ready() && !self.input.port_b_valid && self.input.read_heap_req_valid {
            self.gc_read_granted.connect(&true);
            self.heap_mem.read_b(self.input.read_heap_req_addr);
            // println!("read {} for GC", self.input.read_heap_req_addr);
        }

        // if self.heap_read_valid() {
        //     println!("readout {:?} for GC", self.heap_read_bits());
        // }

        if !self.reg_free_addr.value().0 || self.need_split() {
            self.reg_free_addr
                .connect(&(self.input.free_addr_valid, self.input.free_addr));
        }

        // if self.out_big_drf_valid() && self.out_big_drg_bits().heap_addr == 0 {
        //     println!(
        //         "DHeap emit big drf app with addr 0!, in free addr: {}, valid: {}",
        //         self.input.free_addr, self.input.free_addr_valid
        //     );
        // }
        if self.stat_detail_lv >= DLV_GC {
            if self.stalled() {
                self.stat.gc_stall_cycles += 1;
                self.stat.gc_current_stall += 1;
            } else {
                self.stat.gc_longest_stall =
                    max(self.stat.gc_longest_stall, self.stat.gc_current_stall);
                self.stat.gc_current_stall = 0;
            }
        }
        Ok(())
    }

    fn update_stat(&mut self) -> std::result::Result<(), std::string::String> {
        // if self.dealloc_valid() && self.dealloc_bits() == 4077 {
        //     println!("deallocate 65!");
        // }
        // if self.heap_mem.input.port_a.addr == 0 && self.heap_mem.input.port_a.is_write {
        //     println!("a write 0: {:?}", self.heap_mem.input.port_a.din);
        // }
        // if self.heap_mem.input.port_b.addr == 0 && self.heap_mem.input.port_b.is_write {
        //     println!(
        //         "b write 0: {:?}, port_b ready: {}, port_b in: {:?}",
        //         self.heap_mem.input.port_b.din,
        //         self.port_b_ready(),
        //         self.input.port_b_bits.load
        //     );
        // }

        // let look_at_1 = 67960;
        // let look_at_2 = 67748;
        // println!(
        //     "addr-{} | working: {} | {:?} | addr-{} | working: {} | {:?}",
        //     look_at_1,
        //     self.working_heap.ram[look_at_1],
        //     self.heap_mem.ram[look_at_1],
        //     look_at_2,
        //     self.working_heap.ram[look_at_2],
        //     self.heap_mem.ram[look_at_2]
        // );

        // println!("stack: {:?}", self.thread_stack[0].mem);

        if self.stat_detail_lv >= DLV_FULL_LOG {
            if self.holder_out.0 {
                self.stat
                    .holder_contents
                    .push(Some(self.holder_out.1.clone()));
            } else if self.output_fire() {
                self.stat.holder_contents.push(Some(self.out_main_bits()?));
            } else {
                self.stat.holder_contents.push(None);
            }

            self.stat.heap_stm.push(self.stm.value().clone());
            self.stat.serving_id.push(self.holder_in.value().stack_idx);
        }

        if self.stat_detail_lv >= DLV_THREADS {
            let occupied = self
                .thread_stack
                .iter()
                .filter(|stk| stk.elements() != 0)
                .count();
            if self.port_a_fire() {
                self.stat.active_threads -= 1;
            }
            if self.output_fire() {
                self.stat.active_threads += 1;
            }
            if self.out_io_fire() {
                self.stat.active_threads += 1;
            }
            if self.out_sub_fire() {
                self.stat.active_threads += 1;
            }
            self.stat.work_threads.push((
                occupied as u8,
                self.stat.active_threads + if *self.stm.value() != Stm::Idle { 1 } else { 0 },
            ));
        }

        if self.stat_detail_lv >= DLV_BUSY_RATE {
            if *self.stm.value() != Stm::Idle {
                self.stat.busy_per_cycle.push(true);
            } else {
                self.stat.busy_per_cycle.push(false);
            }
        }
        if self.stat_detail_lv >= DLV_STM_DIST {
            match *self.stm.value() {
                Stm::Idle => self.stat.stm_cycles[0] += 1,
                Stm::Whnf => self.stat.stm_cycles[1] += 1,
                Stm::Ia => self.stat.stm_cycles[2] += 1,
                Stm::Resume => self.stat.stm_cycles[3] += 1,
            }
        }
        Ok(())
    }

    fn tick_children(&mut self) -> std::result::Result<(), std::string::String> {
        self.stm.tick()?;
        for stk in &mut self.thread_stack {
            stk.tick()?
        }
        for stk in &mut self.frame_stack {
            stk.tick()?
        }
        self.heap_mem.tick()?;
        self.working_heap.tick()?;
        self.working.tick()?;
        self.holder_in.tick()?;
        self.arg_id.tick()?;
        self.addr_holder.tick()?;
        self.ia_addr.tick()?;
        self.non_exist.tick()?;
        self.gc_read_granted.tick()?;
        self.reg_free_addr.tick()
    }
}

#[cfg(test)]
mod io_dheap_tests {
    use super::*;

    #[test]
    fn strict_io_arguments_unbox_in_order() {
        let mut read = [Atom::Nop; APP_LENGTH];
        read[0] = Atom::IO(false);
        read[1] = Atom::Ptr(21, false, false);
        read[2] = Atom::Ptr(22, false, false);
        assert_eq!(select_1st_arg(&read), Ok((1, 21)));
        assert_eq!(select_next_arg(&read, 1), Ok((2, 22)));

        let data = [Atom::Int(99), Atom::Nop, Atom::Nop, Atom::Nop,
            Atom::Nop, Atom::Nop, Atom::Nop, Atom::Nop];
        assert!(check_io_target(&read, 1, &data).is_ok());
        let (partially_resolved, extra) = deref(&read, 1, &data, 50);
        assert!(extra.is_none());
        assert_eq!(partially_resolved[1], Atom::Int(99));
        assert!(!io_is_ready(&partially_resolved));
        assert_eq!(select_1st_arg(&partially_resolved), Ok((2, 22)));
        let (ready, _) = deref(&partially_resolved, 2, &data, 50);
        assert!(io_is_ready(&ready));
    }

    #[test]
    fn write_forces_world_after_address_and_data() {
        let mut write = [Atom::Nop; APP_LENGTH];
        write[0] = Atom::IO(true);
        write[1] = Atom::Ptr(10, false, false);
        write[2] = Atom::Ptr(11, false, false);
        write[3] = Atom::Ptr(12, false, false);
        assert_eq!(select_1st_arg(&write), Ok((1, 10)));
        let target = [Atom::Int(5), Atom::Nop, Atom::Nop, Atom::Nop,
            Atom::Nop, Atom::Nop, Atom::Nop, Atom::Nop];
        for position in 1..=3 {
            let (result, _) = deref(&write, position, &target, 99);
            write = result;
            if position < 3 {
                assert!(!io_is_ready(&write));
                assert_eq!(select_1st_arg(&write).unwrap().0, position + 1);
            }
        }
        assert!(io_is_ready(&write));
    }

    #[test]
    fn strict_io_operand_must_be_unboxed_int() {
        let read = slice_to_app(&[
            Atom::IO(false), Atom::Ptr(5, false, false), Atom::Int(0),
        ]);
        let boxed = slice_to_app(&[Atom::Com(1, 2)]);
        assert!(check_io_target(&read, 1, &boxed).is_err());
        let malformed = slice_to_app(&[Atom::IO(false), Atom::Com(1, 2), Atom::Int(0)]);
        assert!(select_1st_arg(&malformed).is_err());
    }

    #[test]
    fn root_world_token_is_an_ordinary_int() {
        let root = vec![Atom::Com(1, 3), Atom::Int(0)];
        let heap = DrfHeap::new(16).program(&vec![root.clone()]);
        assert_eq!(&heap.heap_mem.ram[0][0..2], &root[..]);
    }
}
